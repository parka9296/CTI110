#Ashlee Park
#7/7/25
#P4LAB1
#program that uses turtle to draw a triangle


import turtle
wn = turtle.Screen()
sheldon = turtle.Turtle()

for i in range(3):
    sheldon.forward(150)
    sheldon.left(120)
    sheldon.speed(3)

wn.mainloop()
