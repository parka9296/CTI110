#Ashlee Park
#7/7/25
#P4LAB1
#program uses turtle to draw a square

import turtle
wn = turtle.Screen()
shelly = turtle.Turtle()
sheldon = turtle.Turtle()


for t in [0, 1, 2, 3]:
    shelly.speed(3)
    shelly.forward(150)
    shelly.right(90)


wn.mainloop()
